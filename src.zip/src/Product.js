import React from "react";
import { Card, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import "./Product.css";
import { useStateValue } from "./StateProvider";
function Product({ id, title, img, price, rating, obj }) {
    const [state, dispatch] = useStateValue();
    const addToBasket = () => {
        //dispatch the item into the data layer
        console.log("basket pressed");
        dispatch({
            type: "ADD_TO_BASKET",
            item: {
                id: id,
                title: title,
                image: img,
                price: price,
                rating: rating,
            },
        });
    };
    const pushProduct = (e) => {
        console.log(e.target);
    };
    return (
        <div className="product">
            <div className="product__card">
                <Link
                    to={{
                        pathname: "/product_desc",
                        state: obj,
                    }}
                >
                    <img
                        className="card__img"
                        variant="top"
                        src={img}
                        alt="img"
                        onclick={pushProduct}
                    />
                </Link>
            </div>
        </div>
    );
}

export default Product;
